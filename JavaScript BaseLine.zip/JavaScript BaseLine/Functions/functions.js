let a=prompt("Enter");
let b=prompt("Enter");

const sum=(a,b)=>{
    console.log(a+b);
};
const mul=(a,b)=>{
    console.log(a*b);
};
const div=(a,b)=>{
    console.log(a/b);
};
const sub=(a,b)=>{
    console.log(a-b);
};
const mod=(a,b)=>{
    console.log(a%b);
};
const exp=(a,b)=>{
    console.log(a**b);
};

const printHello=()=>{
    console.log("Hello");
};

