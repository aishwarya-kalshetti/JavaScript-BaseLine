let obj={
    item:"pen",
    price:10,
};
let output=`The cost of ${obj.item} is ${obj.price} `;
console.log(output);

let str1="Hello";
let str2="World";
let str3="  hello world  "

console.log(str1.toUpperCase());
console.log(str1.toLowerCase());
console.log(str3.trim());
console.log(str1.concat(str2));
console.log(str1.length);
console.log(str.slice(0,3));
console.log(str1.replace("Hello","Bye"));
console.log(str1.charAt(0));
console.log("@"+str1+str2);
console.log(str1.indexOf("l"));

