const exp=5;
switch(exp){
    case 1:
        console.log("You are in case 1");
        break;
    case 2:
        console.log("You are in case 2");
        break;
    case 3:
        console.log("You are in case 3");
        break;
    case 4:
        console.log("You are in case 4");
        break;
    case 5:
        console.log("You are in case 5");
        break;
    default:
        console.log("default case");
        break;
    }